import requests
import pandas as pd
from datetime import datetime
from sqlalchemy.orm import Session

from src.app.domain.viticulture import ViticulturaDTO, ViticultureCategory
from src.app.repository.viticulture_repo import RepositorioViticulture

def baixar_e_processar_csv_embrapa(url: str, categoria: ViticultureCategory, db: Session):
    response = requests.get(url)
    response.raise_for_status()

    df = pd.read_csv(pd.compat.StringIO(response.text), sep='\t')
    df = df.dropna(subset=['Produto', 'Ano', 'Quantidade'])

    repo = RepositorioViticulture(db)

    for _, row in df.iterrows():
        try:
            dto = ViticulturaDTO(
                category=categoria,
                subcategory=None,
                item=row['Produto'],
                year=int(row['Ano']),
                value=float(row['Quantidade']),
                unit=row.get('Unidade', 'kg'),
                currency=None,
                source_url=url,
                scraped_at=datetime.utcnow()
            )
            repo.adicionar(dto)
        except Exception as e:
            print(f"Erro ao processar linha: {e}")