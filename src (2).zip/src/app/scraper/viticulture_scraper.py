def get_data_from_embrapa():
    # Aqui virá o Selenium. Exemplo simulado:
    return [{"tipo": "Produção", "valor": "12345"}]